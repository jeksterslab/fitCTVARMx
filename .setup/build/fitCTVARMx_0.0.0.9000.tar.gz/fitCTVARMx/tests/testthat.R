library(testthat)
library(fitCTVARMx)

test_check("fitCTVARMx")
